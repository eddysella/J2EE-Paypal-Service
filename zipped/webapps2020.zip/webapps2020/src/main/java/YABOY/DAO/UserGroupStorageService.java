package YABOY.DAO;

import YABOY.Entities.Credentials;
import YABOY.Entities.UserGroup;
import javax.ejb.Local;

/**
 * @author 164645
 */
@Local
public interface UserGroupStorageService {
    public UserGroup find(Credentials user);
    public void addGroupForUser(UserGroup sys_user_group);
}
